const db = wx.cloud.database()
const _ = db.command

Page({
    data:{
        form:[],   
        popUps: false,
        popUpsMsg: [],
    },

    getList(){
        //调用云函数来获得openid
        wx.cloud.callFunction({
            name:'getData'
        })
        
        .then(res=>{
            console.log("用户openid",res.result.openid)
            db.collection("alumni")
            .orderBy('currentTime',"desc")
            .where({
                _openid:res.result.openid
            })
            .get()
            .then(res=>{
                this.setData({
                    form:res.data
                })
            })
        })
        
        .catch(err=>{
            console.log("失败",err)
        })
    },
    onLoad(){
        wx.startPullDownRefresh()
        this.getList()
    },
    goApplication(){
        wx.redirectTo({
          url: '../application/application',
        })
    },
    popUps(e) {
        console.log("可以")
        console.log(e.currentTarget.dataset._id)
        db.collection("alumni")
            .where({
                _id: e.currentTarget.dataset._id
            })
            .get()
            .then(res => {
                this.setData({
                    popUpsMsg: res.data,
                    _id: e.currentTarget.dataset._id
                })
            })
            .catch(err => {
                console.log(err)
            })
            // 细节放后面加定时器
            setTimeout(() => {
                this.setData({
                    popUps: true
                })
            }, 300);
    },
    back() {
        this.setData({
            popUps: false
        })
    },
    disappear(){
        this.setData({
            popUps:false
        })
        return
    }
})