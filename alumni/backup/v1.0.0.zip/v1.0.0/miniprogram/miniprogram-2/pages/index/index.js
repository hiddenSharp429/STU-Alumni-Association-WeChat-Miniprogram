Page({
    data: {
        popShow:false
    },

    onLoad(options) {

    },
goNew(){
    let that = this
    wx.login({
        success(e) {
          console.log(e.code)
          that.setData({
            wxCode:e.code
          })
          console.log(that.data.wxCode)
          wx.showModal({
            title: '温馨提示',
            content: '微信授权登录后才能正常使用小程序功能',
            cancelText: '拒绝',
            confirmText: '同意',
            success(res) {
                console.log(res.confirm)
              //调用微信小程序的获取用户信息的接口
              if(res.confirm){
                wx.getUserProfile({
                    desc: '用于完善会员资料', // 声明获取用户个人信息后的用途
                    lang: 'zh_CN',
                    success(info) {
                      that.setData({
                        popShow:true,
                      })
                      console.log(info)
                      setTimeout(() => {
                        wx.navigateTo({
                            url: '../new/new',
                            success(){
                                that.setData({
                                    popShow:false
                                })
                            }
                          })
                        }, 2000);
                    },
                    fail(e) {
                      console.log('获取用户信息失败', e)
                    }
                  })
                   // 获取用户的openid
              wx.cloud.callFunction({
                name:"backOpenID",
                success:(res)=>{
                  console.log(res.result.openid)
                }
              })
              }
              else return
            },
            fail() {
              console.log("拒绝")
            },
            complete() {}
          })
  
        },
        fail(e) {
          console.log('fail', e)
          wx.showToast({
            title: '网络异常',
            duration: 2000
          })
          return
        }
      })
    
},
goTeacher(){
    wx.navigateTo({
      url: '../goTeacher/goTeacher',
    })
},
goCompanions(){
    let that = this
    wx.login({
        success(e) {
          console.log(e.code)
          that.setData({
            wxCode:e.code
          })
          console.log(that.data.wxCode)
          wx.showModal({
            title: '温馨提示',
            content: '微信授权登录后才能正常使用小程序功能',
            cancelText: '拒绝',
            confirmText: '同意',
            success(res) {
                console.log(res.confirm)
              //调用微信小程序的获取用户信息的接口
              if(res.confirm){
                that.setData({
                    popShow:true
                })
                wx.getUserProfile({
                    desc: '用于完善会员资料', // 声明获取用户个人信息后的用途
                    lang: 'zh_CN',
                    success(info) {
                      console.log(info)
                      setTimeout(()=>{
                        wx.navigateTo({
                            url: '../goCompanions/goCompanions',
                            success(){
                                that.setData({
                                    popShow:false
                                })
                            }
                        },2000)
                      })
                      
                    },
                    fail(e) {
                      console.log('获取用户信息失败', e)
                    }
                  })
                   // 获取用户的openid
              wx.cloud.callFunction({
                name:"backOpenID",
                success:(res)=>{
                  console.log(res.result.openid)
                }
              })
              }
              else return
            },
            fail() {
              console.log("拒绝")
            },
            complete() {}
          })
  
        },
        fail(e) {
          console.log('fail', e)
          wx.showToast({
            title: '网络异常',
            duration: 2000
          })
          return
        }
      })
    

}
})