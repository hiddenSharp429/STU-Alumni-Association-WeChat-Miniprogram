// app.js
App({
    onLaunch(){
        wx.cloud.init({
            env:'cloud1-0glmim4o153108f5'
        })
    }
})
