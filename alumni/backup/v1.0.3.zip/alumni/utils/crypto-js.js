var CryptoJS = require('crypto-js/crypto-js');
// 密钥 16 位
var key = 'wxf914d7bf204dac';
// 初始向量 initial vector 16 位
var iv = 'wxf914d7bf204dac';
// key 和 iv 可以一致
key = CryptoJS.enc.Utf8.parse(key);
iv = CryptoJS.enc.Utf8.parse(iv);
//加密
function encrypted(param) {
  var encrypted = CryptoJS.AES.encrypt(param, key, {
    iv: iv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7
  });
  encrypted = encrypted.toString();
  return encrypted;
}

//解密
function decrypted(param) {
  var decrypted = CryptoJS.AES.decrypt(param, key, {
    iv: iv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7
  });
  decrypted = CryptoJS.enc.Utf8.stringify(decrypted);
  return decrypted;
}
module.exports = {
  encrypted: encrypted,
  decrypted: decrypted,
}