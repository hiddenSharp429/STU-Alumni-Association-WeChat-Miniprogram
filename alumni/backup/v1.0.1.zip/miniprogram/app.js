// app.js
App({
    onLaunch(){
        wx.cloud.init({
            env:'huahuabuhua-5gg18vlh5e47ced9'
        })
    }
})
