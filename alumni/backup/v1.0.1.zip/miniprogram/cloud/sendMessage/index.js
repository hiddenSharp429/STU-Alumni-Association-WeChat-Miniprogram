const cloud = require('wx-server-sdk')
cloud.init({
  env: 'huahuabuhua-5gg18vlh5e47ced9',
})
exports.main = async (event, context) => {
  const sd = require('silly-datetime');
  const time = sd.format(new Date(), 'YYYY-MM-DD HH:mm');
  let openid = event.openid
  let userName = event.userName
  let state = event.state
  let type = event.type

  if(type == "alumni"){
       try {
              const result = await cloud.openapi.subscribeMessage.send({
              "touser": openid,
              "page": 'index',
              "lang": 'zh_CN',
              "data": {
              "phrase9": {
                     "value": state
              },
              "thing5": {
                     "value": appointmentName
              },
              "name1": {
                     "value": userName
              },
              "name10": {
                     "value": teacher
              },
              "time22":{
                     "value": appointmentTime
              }
              },
              "templateId": 'ITKk6SuK7iPtD5iCqMLVFkm0B4sVq_3iFNyXq9cKwRM',
              "miniprogramState": 'developer'
              })
              return JSON.parse(JSON.stringify(result))
       } 
       catch (err) {
              return err
       }
}
  else{
       try {
              const result = await cloud.openapi.subscribeMessage.send({
              "touser": openid,
              "page": 'index',
              "lang": 'zh_CN',
              "data": {
              "phrase1": {
                     "value": state
              },
              "thing2": {
                     "value": activityName
              },
              "time3": {
                     "value": activityTime
              },
              "name4": {
                     "value": userName
              },
              "time11":{
                     "value": time
              }
              },
              "templateId": 'KSfQkKmnbmBt6KhiRrKKQMXf5yK6nuQTVt8JbdxmLHk',
              "miniprogramState": 'developer'
              })
              return JSON.parse(JSON.stringify(result))
       } 
       catch (err) {
              return err
       }
  }
}