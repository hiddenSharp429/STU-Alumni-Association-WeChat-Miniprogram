export declare const link: string;
