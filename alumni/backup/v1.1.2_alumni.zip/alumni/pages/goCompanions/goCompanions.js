const db = wx.cloud.database()
const _ = db.command

Page({
    data: {
        canIUseGetUserProfile: false,
        form: []
    },

    getList() {
        //调用云函数来获得openid
        wx.cloud.callFunction({
                name: 'getData'
            })

            .then(res => {
                console.log("用户openid", res.result.openid)
                db.collection("accompanyAlumni")
                    .orderBy('currentTime', 'desc')
                    .where({
                        _openid: res.result.openid
                    })
                    .get()
                    .then(res => {
                        console.log(res)
                        this.setData({
                            form: res.data
                        })
                        wx.stopPullDownRefresh()
                    })
            })

            .catch(err => {
                console.log("失败", err)
            })
    },

    onLoad() {
        wx.startPullDownRefresh()
        this.getList()
    },

    goApplication() {
        let that = this
        wx.showModal({
            title: '申请表将会收集您的相关信息',
            content: '您是否同意',
            cancelText: '拒绝',
            confirmText: '同意',
            complete: (res) => {
                if (res.cancel) {

                }

                if (res.confirm) {
                    that.setData({
                        canIUseGetUserProfile: true
                    })
                    if (that.data.canIUseGetUserProfile) {
                        wx.redirectTo({
                            url: '/pages/companionsApplication/companionsApplication',
                        })
                    }

                }
            }
        })
    }
})