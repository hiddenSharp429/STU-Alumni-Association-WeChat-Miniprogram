const db = wx.cloud.database()
const _ = db.command

Page({
    data:{
        form:[],   
        popUps: false,
        popUpsMsg: [],
        isready:"",
        _id:""
    },

    getList(){
        //调用云函数来获得openid
        wx.cloud.callFunction({
            name:'getData'
        })
        
        .then(res=>{
            console.log("用户openid",res.result.openid)
            db.collection("alumni")
            .orderBy('currentTime',"desc")
            .where({
                _openid:res.result.openid
            })
            .get()
            .then(res=>{
                this.setData({
                    form:res.data
                })
            })
        })
        
        .catch(err=>{
            console.log("失败",err)
        })
    },
    onLoad(){
        wx.startPullDownRefresh()
        this.getList()
        // this.isrevise()
    },
    goApplication(){
        wx.redirectTo({
          url: '../application/application',
        })
    },
    popUps(e) {
        console.log("可以")
        console.log(e.currentTarget.dataset._id)
        db.collection("alumni")
            .where({
                _id: e.currentTarget.dataset._id
            })
            .get()
            .then(res => {
                console.log("这里是"+e.currentTarget.dataset._id)
                this.setData({
                    popUpsMsg: res.data,
                    _id: e.currentTarget.dataset._id,
                    isready:res.data[0].isready
                })
            })
            .catch(err => {
                console.log(err)
            })
            // 细节放后面加定时器
            setTimeout(() => {
                this.setData({
                    popUps: true
                })
            }, 300);
    },
    //更正表单信息
    revise(){
        // db.collection("alumni")
        // .where({
        //     _id:this.data._id
        // })
        // .update({
        //     data:{
        //         revise:true
        //     }
        // })
        // .then(r => {
        //     console.log("成功")
        // })
        // .catch(e => {
        //     console.log(e)
        // })  
        console.log("这里是"+this.data._id)
        let _id = this.data._id
        wx.navigateTo({
          url: '../reviseApplication/reviseApplication?_id='+_id,
        })
    },
    back() {
        this.setData({
            popUps: false
        })
    },
    disappear(){
        this.setData({
            popUps:false
        })
        return
    }
})