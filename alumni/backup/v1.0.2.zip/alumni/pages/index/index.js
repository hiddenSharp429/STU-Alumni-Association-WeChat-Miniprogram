Page({
    data: {
        popShow:false,
        isteacher:false,
        openid:"",
        secret:false,
        key:"",
        keyWord:"shantoudaxue"
    },

    onLoad(options) {
        setTimeout(()=>{
            this.identify()
        },0
        )
        // this.identify()
        
    },
    //判断教师还是学生
    identify(){
        wx.cloud.callFunction({
            name:"getData"
        })
        .then(res => {
            // console.log(res.result.openid)
            this.setData({
                openid: res.result.openid
            })
        })
        .catch(err => {
            console.log(err)
        })
        wx.cloud.database().collection("teacherRegister")
        .where({
            _openid:this.data.openid
        })
        .get()
        .then(res => {
            console.log(res)
            if(res.data.length != 0){
                this.setData({
                    isteacher:true
                })
            }
        })
    },
    goNew(){
        let that = this
        wx.login({
            success(e) {
            console.log(e.code)
            that.setData({
                wxCode:e.code
            })
            console.log(that.data.wxCode)
            wx.showModal({
                title: '温馨提示',
                content: '微信授权登录后才能正常使用小程序功能',
                cancelText: '拒绝',
                confirmText: '同意',
                success(res) {
                    console.log(res.confirm)
                //调用微信小程序的获取用户信息的接口
                if(res.confirm){
                    that.setData({
                        popShow:true
                    })
                    wx.getUserProfile({
                        desc: '用于完善会员资料', // 声明获取用户个人信息后的用途
                        lang: 'zh_CN',
                        success(info) {
                        console.log(info)
                        setTimeout(() => {
                            wx.navigateTo({
                                url: '../new/new',
                                success(){
                                    that.setData({
                                        popShow:false
                                    })
                                }
                            })
                            }, 0);
                        },
                        fail(e) {
                        console.log('获取用户信息失败', e)
                        }
                    })
                    // 获取用户的openid
                wx.cloud.callFunction({
                    name:"backOpenID",
                    success:(res)=>{
                    console.log(res.result.openid)
                    }
                })
                }
                else return
                },
                fail() {
                console.log("拒绝")
                },
                complete() {}
            })
    
            },
            fail(e) {
            console.log('fail', e)
            wx.showToast({
                title: '网络异常',
                duration: 2000
            })
            return
            }
        })
        
    },
    goTeacher(){
        wx.navigateTo({
        url: '../approval/approval',
        })
    },
    goApprovalOptions(){
        wx.navigateTo({
            url: '../approvalOptions/approvalOptions',
        })
        
    },
    goCompanions(){
        let that = this
        wx.login({
            success(e) {
            console.log(e.code)
            that.setData({
                wxCode:e.code
            })
            console.log(that.data.wxCode)
            wx.showModal({
                title: '温馨提示',
                content: '微信授权登录后才能正常使用小程序功能',
                cancelText: '拒绝',
                confirmText: '同意',
                success(res) {
                console.log(res.confirm)
                //调用微信小程序的获取用户信息的接口
                if(res.confirm){
                        that.setData({
                            popShow:true
                        })
                    wx.getUserProfile({
                        desc: '用于完善会员资料', // 声明获取用户个人信息后的用途
                        lang: 'zh_CN',
                        success(info) {
                            setTimeout(() => {
                                wx.navigateTo({
                                    url: '../goCompanions/goCompanions',
                                    success(){
                                        that.setData({
                                            popShow:false
                                        })
                                    }
                                })
                                }, 0);
                        },
                        fail(e) {
                        console.log('获取用户信息失败', e)
                        }
                    })
                    // 获取用户的openid
                wx.cloud.callFunction({
                    name:"backOpenID",
                    success:(res)=>{
                    console.log(res.result.openid)
                    }
                })
                }
                else return
                },
                fail() {
                console.log("拒绝")
                },
                complete() {}
            })
    
            },
            fail(e) {
            console.log('fail', e)
            wx.showToast({
                title: '网络异常',
                duration: 2000
            })
            return
            }
        })
    },
    goTeacherRegister(){
        wx.navigateTo({
        url: '../goTeacher/goTeacher',
        })
    },
    enterSecretChannel(){
        this.setData({
            secret:true
        })
    },
    inputKey(e){
        console.log(e.detail.value)
        this.setData({
            key:e.detail.value
        })
    },
    enterSecret(){
        let that = this
        if(this.data.key == this.data.keyWord)
        {
            this.setData({
                popShow:true
            })
            wx.navigateTo({
            url: '../goTeacher/goTeacher',
            })
        }
        else
        {
            wx.showToast({
                title: 'wrong key',
                icon:"error",
                duration: 2000
            })
        }
        
    },
    lookGuide() {
        wx.showModal({
               title:'.....操作手册',
               content:"https://docs.qq.com/doc/DYmNjcmFlT0dtU1lD",
               showCancel:true,
               confirmText:'复制地址',
                      success(res){
                             if (res.confirm) {
                                    wx.setClipboardData({
                                    data: "https://docs.qq.com/doc/DYmNjcmFlT0dtU1lD",
                                    success(res) {
                                    wx.getClipboardData({
                                    success(res) {
                                           console.log(res.data) // data
                                    }
                                    })
                                    }
                                    })
                             }
                      }
                      
               })

    },
    onClose(){
        this.setData({
            secret:false
        })
    }
})